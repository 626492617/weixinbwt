//lists.js
//获取应用实例
var app = getApp()
var page = 1;
var rows = 2;
var iswifi = true;
var param = {
  data: {
    newlist: [],
    display:'none'
  },
  //事件处理函数
  bindViewTap: function () {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  remindertest:function(){
    //网络类型
    wx.getNetworkType({
      success: function (res) {
        // 返回网络类型, 有效值：
        // wifi/2g/3g/4g/unknown(Android下不常见的网络类型)/none(无网络)
        var networkType = res.networkType;
        if (networkType != 'wifi') {
          if (iswifi) {
            //显示温馨提示网络
            wx.showModal({
              title: '温馨提示',
              content: '您现在的网络不是wifi，可能会产生流量费用',
              showCancel: false,
              success: function (res) {
                if (res.confirm) {
                  console.log('用户点击确定')
                } else if (res.cancel) {
                  console.log('用户点击取消')
                }
              }
            })
            iswifi = false;
          }

        } else {
          if (!iswifi) {
            iswifi = true;
          }
        }
      }
    })
  },
  loaddata:function(){
    var that = this
    //温馨提示网络
    this.remindertest();
    wx.showLoading({
      title: '努力加载中',
    })
    //远程数据
    wx.request({
      url: 'http://192.168.3.125:8080/com_pf_test_api/SelectApiAllNews.do', //仅为示例，并非真实的接口地址
      data: {
        'page': page,
        'rows': rows
      },
      header: {
        'content-type': 'application/json'
      },
      //弹出数据
      success: function (res) {
        wx.hideLoading();
        if (res.data.length == 0){
          wx.showToast({
            title: '没有更多数据啦！！',
            icon: 'success',
            duration: 1500
          })
          that.setData({
            display: 'none'
          })
          return false;
        }
        //console.log(that.data.newlist.concat(res.data))
        //把数组合起来 添加到页面上
        //that.data.newlist.concat(res.data);
        that.setData({
          newlist: that.data.newlist.concat(res.data)
        })
        that.setData({
          display: ''
        })
      }
    })
  },
  //加载更多
  loaddatanews:function() {
    page++;
    this.loaddata();
  },
  //页面初始化
  onLoad: function () {
    wx.showNavigationBarLoading()
    wx.setNavigationBarTitle({
      title: '列表'
    });
    var that = this
    this.loaddata();

  },
  onReady:function(){
    
    wx.hideNavigationBarLoading()
  }
}
Page(param)
