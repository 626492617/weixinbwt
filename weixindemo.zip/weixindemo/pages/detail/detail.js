//detail.js
//获取应用实例
var app = getApp()
var param = {
  data: {
    newlist: 
      {
      }
  },
  //事件处理函数
  bindViewTap: function () {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  onLoad: function (options) {
    var that = this
    wx.showNavigationBarLoading();
    wx.setNavigationBarTitle({
      title: '内容'
    });
    wx.request({
      url: 'http://192.168.3.125:8080/com_pf_test_api/SelectApiByIdNews.do', //仅为示例，并非真实的接口地址
      data: {
        'id': options.id
      },
      header: {
        'content-type': 'application/json'
      },
      //弹出数据
      success: function (res) {
        //把数组合起来 添加到页面上
        //that.data.newlist.concat(res.data);
        that.setData({
          newlist: res.data
        })
      }
    })
  },
  onReady: function () {
    
    wx.hideNavigationBarLoading()
  }

}
Page(param)
