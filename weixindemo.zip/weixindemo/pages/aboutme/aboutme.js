//avoutme.js
/***
 *
 */
//获取应用实例
var app = getApp()
var param = {
  data: {
    img: '../../image/timg2.jpg',
    title: '阿拉法科技集团',
    intre: '在现今21时间  阿拉法则是最大的互联网集团在现今21时间  阿拉法则是最大的互联网集团，在现今21时间  阿拉法则是最大的互联网集团在现今21时间  阿拉法则是最大的互联网集团在现今21时间  阿拉法则是最大的互联网集团在现今21时间  阿拉法则是最大的互联网集团',
    contact: '联系方式',
    address: 'xxxxx',
    phone: '18888888888',
    cooperation: '6264@com'
  },
  //事件处理函数
  bindViewTap: function () {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  onLoad: function () {
    console.log('onLoad')
    var that = this
    //调用应用实例的方法获取全局数据
    app.getUserInfo(function (userInfo) {
      //更新数据
      that.setData({
        userInfo: userInfo
      })
    })
  },
  onReady: function () {
    wx.setNavigationBarTitle({
      title: '内容'
    });
    wx.hideNavigationBarLoading()
  }
}
Page(param)
