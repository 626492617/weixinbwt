//index.js
//获取应用实例
var param = {
  data: {
    mytext: '显示点击的内容！！！',
    typewx:''
  },
  aaa:function(e){
    console.log(e);
    param.data.typewx = 'true';
    this.setData(param.data);
  },
  bbb:function(e){
    console.log(1);
    param.data.typewx = '';
    this.setData(param.data);
  }
}
Page(param)
