//app.js
var param = {};
App(param)