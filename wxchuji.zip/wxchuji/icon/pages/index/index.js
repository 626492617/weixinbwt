//index.js
//获取应用实例
var param = {
  data: {
    mytext: '显示点击的内容！！！',
    typewx:''
  }
}
Page(param)
