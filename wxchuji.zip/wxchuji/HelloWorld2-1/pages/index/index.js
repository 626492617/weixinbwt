//index.js
//获取应用实例

var param = {
  data: {
    mytext: 'Hello World',
  }
};
Page(param);