//index.js
//获取应用实例
var count1 = 0;
var count2 = 0;
var param = {
  data: {
    mytext: '显示点击的内容！！！'
  },
  clickMe : function(e){
    console.log(e);
    //把view0上点击出来的显示出来
   
    var id = e.currentTarget.id 
    if (id == 'view0'){
      count1++;
      param.data.mytext = '你已经点击了' + id + '第' + count1 + '次';
    }else{
      count2++;
      param.data.mytext = '你已经点击了' + id + '第' + count2 + '次';
    }
    //取data-xxx的值
    console.log(e.currentTarget.dataset);
    console.log(e.currentTarget.dataset.hi);
    console.log(e.currentTarget.dataset.qf);
    this.setData(param.data);
  }
}
Page(param)
