// pages/content/content.js

var app = getApp()
var param = {
  data: {
   
  },
  
  onLoad: function (e) {
    console.log("onLoad");
    var that = this;
    console.log(e);
    console.log(e.nameid);
  }

}
Page(param)
